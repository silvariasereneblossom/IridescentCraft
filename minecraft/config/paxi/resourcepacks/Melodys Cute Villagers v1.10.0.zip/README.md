‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿୨ ♡ ୧‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿

# ‿︵‿︵‿︵‿︵‿︵‿୨ Introduction ୧‿︵‿︵‿︵‿︵‿︵‿


### --- **Thank you for downloading Melody's Cute Girl Villagers!** ---

#### This pack is very dear to me, my aim with this pack is to enhance villagers and give them a wider variety to give them a sense of life and personality. I hope you love them as I do.

#### - This pack is still not fully done and will probably never fully be done but I had to release it eventually make sure to join my discord and follow my socials to keep up with updates!

#### - Suggestions, input, and bug reports are highly appreciated. I really want to know what you guys think so let me know on my discord server!

#### [**♡ Discord**](https://discord.gg/RN3dGQ9SDa)
#### [**♡ Website**](https://melodymews.com/?utm_source=readmecgv2025nov15&utm_medium=readmecgv2025nov15&utm_campaign=readmecgv2025nov15&utm_term=readmecgv2025nov15)

> [!IMPORTANT]
> You need either:

> OptiFine 1.19.2 HD U I1 to OptiFine 1.21.2 for this resource pack to work. It WILL NOT WORK on OptiFine versions 1.21.3 or higher!
> OR
> [EMF] Entity Model Features mod and ETF. (entity culling is recommended too).
> Please be aware that EMF has some issues.
> > Current known EMF issues with this pack include:
> •  Showing the level 5 profession texture for all profession levels. (Master blossom librarian and master elf/fairy farmer).
> •  The wandering traders sounds are completely silent for Minecraft java versions 1.21.2 and above as of this day 14/04/2025 (my guess is this seems to be an issue with Minecraft itself and not OptiFine). Please delete the wandering_trader folder located in "Melodys_Cute_Villagers_v0.9.1\assets\Minecraft\sounds\mob\wandering_trader".

> If the villagers still look broken... then there is likely another conflicting texture pack (two villager textures are overlapping each other from different packs)! To fix this just delete all villager and wandering trader files and folders from the other pack. For example: if you are using "Mizuno's 16 Craft Resource Pack", just search and delete all the villager and wandering trader files and it should work.

-- Note: You can rename "pack.png" to something else and rename "pack2.png" to "pack.png" to have the pink girl as the pack icon.

> [Recommended]
> I prefer to use this pack with "Mizuno's 16 Craft Resource Pack".
> The preferred shaders are "Sildur’s Shaders" in the overworld/nether and "Complementary Shaders Reimagined" in the end and nether world.


# ‿︵‿︵‿︵‿︵‿︵‿୨ Updates ୧‿︵‿︵‿︵‿︵‿︵‿

## ♡ 14/03/2026 v1.10.0 (Domestication Innovation Mod Support)
# • Made guard villagers use default sound instead of cute girl sound.
# • Added support for Domestication Innovation Mod.
# • Changed Savanna eye colors spawn percentage (Pink & Orange: 45%, Green: 9.95%, Albino: 0.05%).

## ♡ 08/03/2026 v1.9.0 (Homesteads Mod Support)
# • Added support for "Homesteads - Villager Expansion & New Professions" mod.
# • Changed max supported formats to 9999 in pack.mcmeta.
# • Fixed back of left arm of lumberjack skin for "Lumberjacks!" mod.

## ♡ 03/03/2026 v1.8.0 (Nature's Spirit Mod Support)
# • Added basic support for Natures Spirirt Mod, (Only one hair type for each villager type) I want to make it better later though. PLEASE REPORT ANY ISSUES!
# • Fixed version in pack.mcmeta file so it doesn't throw an error for new versions of minecraft.
# • Fixed miscolored pixels in villager2.png.
# • Deleted random files in cem folder.
# • Added update titles in README.md file.

## ♡ 13/02/2026 v1.7.0 (Cobblemon Support)
# • Fixed some syntax errors in villager.properties for cem (some professions were written as profession instead).
# • Added support for the nurse and nurse joy profession for villagers in the cobblemon mod.
# • Fixed some syntax errors somewhere else too but I forgot where (numbers were wrong for some rules).

## ♡ 09/01/2026 v1.6.0 (Separated Witches & Illagers)
# • Separated Illagers and Witches into their own packs.
# • Updated README.md file.

## ♡ 29/12/2025 v1.5.0 (RCT Mod Support)
# • Changed elf chest design (again).
# • Added texture support for the trainer association villager from the "Radical Cobblemon Trainers" Mod.

## ♡ 19/12/2025 v1.4.2 (Aesthetic Fixes)
# • Fixed hair and bow design on several CEM models.
# • Fixed color contrast of blossom fletcher.
# • Altered colors of Red Rock villagers (Biomes We've Gone Mod).
# • Darkened dark version of water lily (lotus) and carnation flower farmer texture for savanna.
# • Darkned purple dark forest elf hair.
# • Altered Elf chest clothes design.
# • Altered Snow chest clothes deisgn.

## ♡ 14/12/2025 v1.4.1 (Major Fixes)
# • Fixed baby sunflower plains not blinking on Optifine.
# • Added missing Optifine blinking for albino plains flower farmers and many others including taiga flower farmers.
# • Removed wandering_trader.properties
# • Removed bbmodel file.
# • Fixed a syntax error in cem/villager.properties that could've potentially used the wrong model for the shady wizard (moddded profession).
# • Fixed short hair baby sunflower plains hair and removed old skirt top unused texture.
# • Deleted desert2.properties in anim/blinks/villager due to being a duplicate.
# • Fixed one of the purple aliens having the wrong blink eye color for EMF/ETF.

## ♡ 13/12/2025 v1.4.0 (Green Eyed Savanna Variant & Fixes) [BROKEN]
# • Added new green eyed savanna variant.
# • Changed colors of savanna, hills, desert, plains, maple, etc villagers, wandering trader and savanna witch.
# • Fixed witches, savanna32.png, plains937.png, plains939.png, desert56.png, plains338.png and, snow20.png not blinking.
# • changed "Shiny Mobs!" villager eye colors.
# • Added blinking animation for "Shiny Mobs!" eyes.
# • Added easter egg.
# • Fixed Optifine blinking for birch villagers.

## ♡ 03/12/2025 v1.3.0 (Let's Do Mods Support & Fixes)
# • Added support for Sandy Merchant (Let's Do BeachParty Mod)
# • Added support for Cook (Let's Do Candle Light Mod)
# • Fixed Chef's hat for elf/fairy villagers (Chef's Delight Mod).
# • Changed UV position of top of hat for villager9.jem (fairy/elf model) to match other villagers.
# • Fixed Enginner texture being broken on fairy villager (Immersive Engineering).
# • Added blink support to werewolf (Evilcraft) for EMF/ETF.
# • Rerranged Wandering Trader Textures UV Positions.
# • Altered Wandering Trader CEM file.
# • Fixed albino wandering trader blush being wrong color when hurt animation.
# • Added support for Winermaker & Wandering Winemaker (Let's Do Vinery Mod)

## ♡ 01/12/2025 v1.2.0 (Stoneblock 4 Compatibility & Fixes)
# • Added support for Stone type villagers (ftb:stone for FTB StoneBlock 4)
# • Added support for Archaeologist, Dimensionalist, Geologist and the Echoes Projection from "FTB StoneBlock 4" Modpack.
# • Added support for chefs delight fabric version. (The profession pngs apparently have different names than the forge version of that mod). [NOT TESTED]

## ♡ 28/11/2025 v1.1.1 (Fixes & Compatibility)
# • Fixed previous version not able to reload properly because of an accidental new line in "Alien villager hats (Modded)" section of the villager.properties file.
# • Added villager head support.
# • Fixed plains937 (one of the baby albino birch villagers) not blinking by removing the space off plains937blink.png.
# • Tried adding villager heads but not working.
# • Fixed back texture of cherry blossom nitwit (flower crown version).
# • Added compatibility with "Mizuno's 16 Craft Resource Pack" (should work with without needing to delete anything now).
# • Changed the icon back to v1.0.0 icon.

## ♡ 18/11/2025 v1.1.0 (Added Merchant Support) [Broken]
# • Added temporary support for the merchant from the "Farming for Blockheads" mod. It will not work if you change the name of the villager. (I couldn't find a better fix)
# • Updated pack icon.

## ♡ 15/11/2025 v1.0.0 (Release)
# • Pack full release.
# • Updated README.md.
# • Changed default villager texture png look.
# • Altered Villager10 & Villager9 CEM files to fix elf cartographer sleeve puff not showing.
# • Fixed baby elf hovering/flying.
# • Adjusted birch eye color spawning rate.
# • Fixed blossom nitwit flower crown and changed model used.

## ♡ 11/11/2025 v0.17.0
### • Added new Birch villager with EMF & OptiFine supported blinking.
### • Fixed wrong witch alien spawn rate. 
### • Lightened pink end (alien) witch hair.
### • Fixed pink end witch belt not glowing.
### • Changed elf cartographer CEM and changed positioning of fairy cartographer monocle to match.
### • Added short hair witch variant (4:1 long to short hair ratio).
### • Fairy now doesn't wear elf farmer clothes due to EMF showing master farmer level clothes for all farmer levels.
### • Adjusted color of brown eyed plains and sunflower.
### • Removed stray pixels from some baby textures.
### • Fixed some babies short hair variant having long bangs.

## ♡ 06/11/2025 v0.16.0
### • Fixed issue with pack breaking on OptiFine. (OF 1.19.2 HD U I1 - OF 1.21.2)
### • Removed random extra copy witch files.
### • Added missing villager.data.type = Minecraft:plains in the villager.properties file.
### • Rewrote profession level properties files (stone, iron, etc) and CEM villager properties file to split modded profession regex so it can work for OptiFine.
### • Fixed warm ocean (Hawaiian/Tropical) armorer level texture bug.
### • Fixed Hawaiian flower farmer spawning wrong.
### • Fixed Hawaiian shepherd level look (removed flower crown that showed with hat and added neck piece).
### • Added comments for profession levels files.
### • Changed hand grass design of farmer536.png.
### • Changed hand design for all tropical profession levels except for flower farmer.
### • Removed Hawaiian villager profession level combo comments and moved it to profession level files.
### • Added computer scientist link to modded professions list in readme.md.
### • Changed beekeeper (modded profession) design.
### • Made blossom farmer & blossom nitwit not wear default outfit under profession outfit.
### • Edited blossom [nitwit, farmer, leatherworker & toolsmith] outfits.
### • Added OptiFine (anim) blinking for sunflower witch.
### • Added new blossom nitwit flower crown variant.

## ♡ 25/10/2025 v0.15.0
### • Added More modded professions, including: jeweler, werewolf, forager, fluix researcher, industrialist, cartman, trackman, shady wizard, mechanic and computer scientist (see supported mod profession list for more info)
### • Added some modded biomes (Oh The Biomes We’ve Gone, iceandfire, regions_unexplored, undergarden, deeperdarker, nullscape, etc) for some villagers (elf, maple, blossom, nether, end, etc).
### • Added the three "Oh The Biomes We’ve Gone" villager types (such as salem villager) with flower farmer support.
### • Defined some jobs/biomes more specifically.
### • Changed elf fisherman texture and definition.
### • Fixed short hair on jungle baby albino villager.
### • Fixed desert95.png eye color being too grey (desert baby).
### • Fixed plains165.png and plains170.png having switched eye colors (Blossom villagers).
### • Fixed spawn rate of alien witch.
### • Added witches to some modded biomes (BWG & regions unexplored).
### • Deleted some extra files.
### • Added ETF blinking support for all entities.
### • Added sunflower witch.
### • Fixed purple alien babies being too light compared to adult.
### • Added comments in witch's properties file.
### • Adding missing jungle default texture.
### • Fixed some babies having weird texture above invisible skirt if they don't wear a skirt by rearranging the position of skirt top in Villager2.CEM.
### • Added Mod support for "Shiny! Mobs" mod (but broken for some reason on babies).
### • Removed some extra files.
### • This patch was focused on adding support for the ATM10 modpack, let me know if something is still broken if you are playing on that modpack.

## ♡ 18/10/2025 v0.14.0
### • Added orange-y brown Savanna variant.
### • Added some profession support for some mods (See list below in README.md file).
### • Fixed blossom armorer not having dirt on face.
### • Changed design of default level badges.
### • Fixed thickness of blossom master librarian headband bow.
### • Fixed fairy, snow, hills and, savanna shepherd stick animation.
### • Fixed some villagers sitting animation.
### • Fixed texture issue with some alien professions.
### • Added range version inclusion.
### • Moved Elf/Fairy puffy skirt block up one square for both CEM files.
### • Fixed ginger fairy chest freckles showing over weaponsmith apron.
### • Fixed some farmer warm ocean villagers having flower crown and some don't.
### • Fixed flower farmer warm ocean villager crown texture being broken.
### • Fixed/changed fisherman fairy crown.
### • Removed old extra CEM files.

## ♡ 12/10/2025 v0.13.0
### • Optimized and merged CEM models of ALL villagers (This took the longest time to do).
### • Removed some stray pixels from plains villagers and fixed hair not fully being one color.
### • Adjusted Alien textures (fixed feet bottom, closed arm gap on top, added more contrast to dress colors, removed stray pixels)
### • Updated dress design for default blossom girls and changed positioning of some parts.
### • Changed position of savanna headband corresponding  to new CEM model.
### • Made blossom albino dress more cool toned.
### • Moved position of elf headgear texture.
### • Made plains skin slightly darker.
### • Fixed issue of there being no long hair albino blossom baby.
### • Rearranged some baby textures including blossom.
### • Fixed purple eyed blossom baby's hurt animation eye color being blue.
### • Fixed blossom farmers dresses.
### • Fixed Blossom nitwit easter egg always having blue eyes and long hair.
### • Fixed Some Blossom Shepherds only having blue eyes and long hair.
### • Removed stray pixels from some villagers with no clothes.
### • Updated baby snow texture.
### • Updated baby hill texture.
### • Fixed bangs/fringe on all villagers.
### • Possibly fixed syntax error in shepherd properties file.
### • Added shepherd texture for mushroom.
### • Enhanced Savanna headband.
### • Adjusted several textures to fit the new CEM structure (didn't keep track of which).
### • Fixed blossom librarian easter egg skin ears.
### • Fixed one of the white haired snow villagers shading being too grey.
### • Changed Mushroom texture placements for default and jobs.
### • Remade maple villagers chest ribbon to be higher up so it doesn't look bugged with profression clothes.
### • Gave maple villagers skirt sitting design.
### • Changed Blossom shoe design.
### • Fixed random missing skirt pixel on 2 blossom characters (unless this issue wasn't included in last patch).
### • Fixed dark forest mushroom nitwit outfit.
### • Fixed weaponsmith cave villager scar color when hurt.
### • Fixed extra headwear pixels on fairy fisherman.
### • Altered aliens (End villagers) colors.
### • Fixed one of the pink alien babies shiny head thingy.
### • Fixed some weaponsmiths having missing pixels on chest.
### • Fixed baby maple being normal plains most of the time (accidently gave them the regex code of the flower farmer).
### • Made pink aliens more common.
### • Fixed blinking issue with some villagers.
### • Gave nitwit fairies rainbow headband.
### • Added modded professions texture files but not implemented yet.
### • fisherman has new headpiece (forgot to add this in the previous readme.md).
### • No idea what more I fixed since I started working on this patch in June.

## ♡ 11/06/2025 v0.12.1
### • Added ribbons to cherry blossom shepherd's crooks.
### • Fixed the blush color on cave girl skin without clothes being the wrong color.
### • Desert, savanna, taiga, snow, etc shepherds now show level on chest.
### • Hawaiian (warm ocean) babies now have a head accessory similar to the adult.
### • Added shepherd's crook to all shepherds.
### • Changed Hawaiian shepherd's level flowers look.
### • Added some easter eggs in some cherry blossom professions.

## ♡ 04/06/2025 v0.12.0
### • Removed duplicated headwear for villager84.cem.
### • Elf cartographer dress updated to have map satchel.
### • Lily of the valley and bluebells flower farmers colors adjusted.
### • Gave rose and wisteria flower farmer a flower crown.
### • Updated mushroom colors.
### • Updated Elf clothes colors.
### • Edited some Elf CEMs.
### • Removed some old files (old shepherd outfit that wasn't being used).
### • Adjusted color of some mushroom profession clothes, including toolsmith mushroom.
### • Gave Elves without a job headgear (metal crown thingy).
### • New Fairy villager added in the dark forest to live with the elves as a minority (~15% chance of spawning).
### • Added Mushrooms to the dark forest as a minority to live with the elves (~5% chance of spawning).
### • Most villager relating .properties files have been touched.
### • Updated README.md.
### • I don't remember what else I've changed and could not test everything so please let me know if you come across anything you think I might need to know!

## ♡ 22/05/2025 v0.11.0
### • Created new models for illagers and changed existing ones.
### • Changed blinking for villagers, illagers and witches.
### • Adjusted desert hazel eyes color.

## ♡ 07/05/2025 v0.10.0
### • Reworked Desert villager completely.
### • Tweaked desert cleric and librarian.
### • Fixed Snow fisherman skirt being missing/broken.

## ♡ 16/04/2025 v0.9.2
### • Fixed farmer villagers spawning with wrong skins, especially for hills and tropical girls (sometimes they are not wearing a top).
### • Fixed hills flower farmers not blinking and randomly changing eye color when becoming a flower farmer.
### • Cleaned up and organised taiga.properties file.

## ♡ 14/04/2025 v0.9.1
### • Fixed error with flower farmers textures spawning wrong.
### • Fixed wrong CEM models being used in general.
### • [IMPORTANT] The baby villagers are broken for OptiFine versions 1.21.4 and above! *as of this day 14/04/2025* (I sadly could not fix this but I think it's an OptiFine issue)
### • [IMPORTANT] The wandering traders sounds are completely silent for Minecraft java versions 1.21.2 and above (my guess is this seems to be an issue with Minecraft itself and not OptiFine). Please delete the wandering_trader folder located in "Melodys_Cute_Villagers_v0.9.1\assets\Minecraft\sounds\mob\wandering_trader"

## ♡ 20/03/2025 v0.9.0 (very scuffed update because I have to leave for a while)
### • Fixed blossom hair texture asymmetry (front) and part on sides.
### • Fixed sunflower plains leg wrong shade color.
### • Made colors more contrasted on blossom master librarian.
### • Fixed mint haired elf having wrong face texture from Savanna (for blinking).
### • Fixed blossom bow back.
### • Added new illusioner design (scuffed and might be changed later).
### • Removed blaze.
### • Added flower farmers with 5% of farmer villager to spawn as a flower (not fully tested or optimised).
### • Added comments to villager properties files and organised a little.
### • Added "Pack Version Info" section to README.md

## ♡ 09/02/2025 v0.8.0
### • Added Tropical Villagers (warm ocean, lukewarm ocean and deep lukewarm ocean).
### • Added New wandering trader variants.
### • Fixed original wandering trader eye issue.
### • Updated color of hills brown eyes (made darker).
### • Updated textures of mushroom villagers (more contrast).
### • Added new variant of blossom shepherd (blue and pink).
### • Updated texture of the following blossom villagers: shepherd, leatherworker, fisherman, butcher and cleric.
### • Added shepherd's crook to blossom shepherd.
### • Changed blinking animation of all villagers.
### • Potentially fixed the error regarding the blaze.
### • Fixed savanna face color lighter than rest (forgot to add this is README file).

## ♡ 28/01/2025 v0.7.0
### • Added a bunch of witch types and possibly changed the main one.
### • Added/Changed witch sounds.
### • Fixed under chest texture of aliens.
### • Fixed wrong blossom weaponsmith texture spawning due to missing cave girl weaponsmith texture missing.
### • Added a weaponsmith cave girl texture.
### • Added red blossom farmer (cherry grove biome).
### • Adjusted the colors of the rest of the blossom farmers (let me know if it's better or worse).
### • Blossom villagers now properly show up in some modded cherry blossom biomes.
### • I honestly don't remember what else I changed/added, please let me know if anything seems off/broken/different.

## ♡ 14/11/2024 v0.6.0
### • Added wandering trader texture and model.
### • Added witch texture and model.
### • Added wandering trader sounds.
### • Added new hills villager variant.
### • Added blinking for hills villagers, alien villagers, wandering trader and witch.
### • Made purple aliens more purple.

## ♡ 16/09/2024 v0.5.0
### • Fixed Maple blinking eyes animation being the wrong color.
### • Fixed baby elves having missing animations and wrong colors.
### • Added new pack icon options.
### • Added two nether villager types.
### • Added compatibility for modded biomes for nether villagers (not tested).
### • Updated loading screen colors.
### • Updated README.md.

## ♡ 12/09/2024 v0.4.1
### • Made savanna hair and skin darker.
### • Fixed baby plains and gave them socks.
### • Fixed not adding byg tag before the biome name for maple girls spawn biomes.
### • Adding blinking to maple girls.
### • Added proper job clothes for maple and cave girls.
### • Updated README.md

## ♡ 21/08/2024 v0.4.0
### • Added Elf villager.
### • Added Maple villager (modded only) [NOT TESTED]
### • Fixed mushroom (and other villagers) professions from appearing on the wrong villager.

## ♡ 23/05/2024 v0.3.0
### • Added Cave villager.

## ♡ 24/04/2024 v0.2.4
### • Updated README.md file with guide about villagers.

## ♡ 14/04/2024 v0.2.3
### • Changed file type from rar to zip (I'm so sorry I didn't realize I archived it wrong. My PC broke and I am on a laptop with different settings).

## ♡ 06/04/2024 v0.2.2
### • Added original icon as an option.

## ♡ 19/01/2024 v0.2.1
### • Fixed version numbering.
### • Fixed weights for mountain girls.

## ♡ 18/01/2024 v0.2.0
### • Added Alien villager type in The End.
### • Added new taiga villager type in the windswept hills, windswept forest, and windswept gravelly hills biomes called mountain girls.
### • Fixed sitting animation of all adults.
### • Fixed sitting texture of all adults.
### • Fixed Gingers (sunflower plains) regular and albino arm textures missing or miscolored.
### • Fixed all baby hair glitches (created padding to remove the floating lines).
### • Fixed cherry blossom nitwit eyeshadow.
### • Added frog instead of fish on swamp fisherman.
### • Made yellow-eyed Jungle villagers rarer.
### • Increased chance of blonde snow villagers over white-haired.
### • Changed weights of sunflower villagers spawn (green most likely then brown then blue).
### • Made brown mushroom girls 10% more common.
### • Added scar under eyepatch to weaponsmith when hurt.
### • Potentially completely fixed different villager type models spawning in non official biomes.
### • Fixed armorers arm texture (rounded all decimals for block faces).
### • Minor fixes for librarian sides.


# ‿︵‿︵‿︵‿︵‿︵‿୨ Licensing ୧‿︵‿︵‿︵‿︵‿︵‿

### • Do not resell this pack or its files.
### • Do not redistribute this pack or its files.
### • You are allowed to edit the pack only for personal use and not commercial.
### • You are allowed to stream, screenshot, and make videos with this pack but give credit to me.
### • Keep it wholesome. Don’t use or edit this pack to show gore, torture, or NSFW content. No nudity, fetish/erotic content, or sexualized depictions of minors/age-ambiguous characters. The villagers are meant to be cherished.
### • Use is prohibited for anyone who has engaged in harassment, hate speech, doxxing, cheating, or other malicious conduct toward me or my community, or whose name appears on my blocklist.
### • These rules are subject to change at any time.


# ‿︵‿︵‿︵‿︵‿︵‿୨ Content/Guide ୧‿︵‿︵‿︵‿︵‿︵‿

- Please note that Minecraft has 7 default type villagers (Snow, Plains, Swamp, Jungle, Taiga, Savanna, Desert) and some of the villager types in this pack (blossom, hills, aliens, sunflower, mushroom, etc) are NOT real villager types and by that I mean that they are usually one of the default type villagers (most are plains). For example, blossom villagers are actually just plains villagers that have spawned in the cherry grove biome and that data is temporarily saved in OptiFine and not Minecraft so refreshing (F3 + T) will re-check which biome the villager is in and might change their texture accordingly.
- All villager types except aliens have albinos with around 0.03-0.05% chance of spawning.
- Some shepherds wear a poncho instead of a brown dress with a headscarf.
- Some job clothes may have different coloration to match the villager type theme.
- Below are the approximate spawn percentage rates, they are NOT 100% accurate. (Moslty because I suck at math.)
- You are welcome to change spawn rates and textures if you like.
- The information below could be outdated or incomplete.


# ‿︵‿︵‿︵‿୨ Villagers Info ୧‿︵‿︵‿︵‿

• Plains (Default)
Biome: Plains and all biomes not mentioned (See note at the end of this section for all the biomes)
Type: Plains
Info: Brown hair with different spawn percentage of eye colors.
Spawn Rates: (Blue ≈ 3%, Brown ≈ 80%, Green ≈ 15%, Albino ≈ 0.03-0.05%)

• Taiga (Default)
Biome: Taiga Biomes except windswept_hills, windswept_forest & windswept_gravelly_hills (See note at the end of this section for all the biomes)
Type: Taiga
Info: Two variants of black hair periwinkle eyes and brown hair emerald eyes.
Spawn Rates: black hair periwinkle eyes (≈ 65%), brown hair emerald eyes (≈ 35%).

• Savanna (Default) 
Biome: Savanna Biomes (See note at the end of this section for all the biomes)
Type: Savanna
Info: Three variants of dark skinned rose (≈ 45%), orange (≈ 45%) and green eyes (≈ 9.95%).

• Desert (Default)
Biome: Desert Biomes (See note at the end of this section for all the biomes)
Type: Desert
Info: Hair color variants of brown, black and blonde. Eye variants of brown, hazel and grey (percentages are in the desert.properties file).

• Snow (Default)
Biome: Snow Biomes (See note at the end of this section for all the biomes)
Type: Snow
Info: Two varriants of blonde blue eyes and white haired indigo eyes.
Spawn Rates: blonde blue eyes (≈ 60%), white haired indigo eyes (≈ 40%)

• Jungle (Default)
Biome: Jungle Biomes (See note at the end of this section for all the biomes)
Type: Jungle
Info: Three variants of green eyes orange hair, green eyes red hair and gold eyes red hair.
Spawn Rates: green eyes orange hair ≈ 40% , green eyes red hair ≈ 40%, gold eyes red hair ≈ 20%.

• Swamp (Default)
Biome: Swamp Biomes (See note at the end of this section for all the biomes)
Type: Swamp
Info: One variant of greenish looking girls.

• Blossom
Biome: cherry_grove
Type: Plains
Info: Two variants of blue or purple eyes. All have pink hair. Albinos are more likely to spawn here.
More info: They have different job clothes and level badges compared to other villager types. level 5 librarian has a special outfit compared to other levels of librarian. Job clothes have 1-4 different variants and colors. armorer has a (≈ 10%) chance of spawning with glasses on.
Spawn Rates: blue eyes (≈ 79%), purple (≈ 20%), Albino (≈ 1%)

• Mushroom
Biome: mushroom_fields and dark forest
Type: Plains
Info: Two variants of red mushroom hat or brown mushroom hat. Albino variants also come in brown and red. farmer wears green instead of yellow.
Spawn Rates: (5% Chance of spawning between fairies and elves) Red (≈ 80%), Brown (≈ 20%), Albino red (≈ 0.025%), Albino brown (≈ 0.001%)

• Cave (Snow Leopard)
Biome: lush_caves, dripstone_caves, deep_dark (all cave biomes) 
Type: Plains
Info:  One variant of cool tan skinned, black haired, indigo eyed girls.

• Aliens
Biome: the_end, end_highlands, end_midlands, small_end_islands, end_barrens (all end biomes) 
Type: Plains
Info: Two variants of purple and pink. Doesn't have an albino.
Spawn Rates: Purple (≈ 80%), pink (≈ 20%)

• Hills/Mountain 
Biome: windswept_hills, windswept_forest, windswept_gravelly_hills
Type: Taiga
Info: Two variants of mountain girls with tan skin, brown hair and green or brown eyes living on a cold mountain.
Spawn Rates: Green eyes (≈ 60%), Brown eyes (≈ 40%)

• Sunflower
Biome: sunflower_plains biomeswevegone:prairie
Type: Plains
Info: Gingers with freckles. Same eye variety as plains with different percentages.
Spawn Rates: (Blue ≈ 27%, Brown ≈ 4%, Green ≈ 68%, Albino ≈ 0.03-0.05%.)

• Elves 
Biome: dark_forest and biomes from "Biomes O' Plenty" and "Oh The Biomes You'll Go" mods (byg:skyris_vale byg:forgotten_forest byg:black_forest biomesoplenty:mystic_grove)
Type: Plains
Info: Six variants including albino, has long elf ears.
Spawn Rates: (80% Chance of spawning between fairies and mushrooms) Yellow hair ≈ 48.4%, White hair ≈ 37.3%, Purple hair ≈ 6.95%, Green hair ≈ 7.3%, Albino ≈ 0.05%.

• Fairies 
Biome: dark_forest and biomes from "Biomes O' Plenty" and "Oh The Biomes You'll Go" mods (byg:skyris_vale byg:forgotten_forest byg:black_forest biomesoplenty:mystic_grove)
Type: Plains
Info: Four variants including albino, has long pointed ears.
Spawn Rates: (15% Chance of spawning between elves and mushrooms) Pink ≈ 33.3%, Indigo ≈ 33.3%, Green ≈ 33.3%, Albino ≈ 0.05%.

• Birch
Biome: birch_forest old_growth_birch_forest regions_unexplored:silver_birch_forest
Type: Plains
Info: Blonde. Blue dress.
Spawn Rates: (percentages are in the desert.properties file).

• Maple [Modded biomes only]
Biome: biomes from "Biomes O' Plenty" and "Oh The Biomes You'll Go" mods (seasonal_deciduous_clearing byg:seasonal_deciduous_forest_hills byg:maple_taiga byg:autumnal_forest byg:autumnal_valley byg:autumnal_taiga byg:seasonal_birch_forest byg:seasonal_deciduous_forest biomesoplenty:aspen_glade biomesoplenty:maple_woods biomesoplenty:snowy_maple_woods biomesoplenty:seasonal_forest biomesoplenty:pumpkin_patch)
Type: Plains
Info: Auburn hair and emerald eyes.

• Nether Brown
Biome: nether_wastes, crimson_forest and warped_forest
Type: Plains
Info: Dusty look of the default plains with brown hair with different spawn percentage of eye colors, ripped clothes and dust on clothes/skin.
Spawn Rates: (Blue ≈ 3%, Brown ≈ 80%, Green ≈ 15%, Albino ≈ 0.03-0.05%)

• Nether Black 
Biome: soul_sand_valley and basalt_deltas
Type: Plains
Info: Dusty colors and darker brown hair. Different spawn percentage of eye colors, ripped black clothes and dust on clothes/skin.
Spawn Rates: (Blue ≈ 3%, Brown ≈ 80%, Green ≈ 15%, Albino ≈ 0.03-0.05%)

• Red Rock [Oh The Biomes We've Gone Mod]
Biome: red_rock_valley
Type: Red Rock
Info: Dark brown hair, brown eyes and tan skin wearing tan clothes and red headpiece.
Spawn Rates: (Main variant ≈ 99.95%, Albino ≈ 0.03-0.05%)

• Salem [Oh The Biomes We've Gone Mod] 
Biome: weeping_witch_forest
Type: Salem
Info: Dark brown hair, green eyes and pale skin wearing black with a belt.
Spawn Rates: (Main variant ≈ 99.95%, Albino ≈ 0.03-0.05%)

• Skyris [Oh The Biomes We've Gone Mod] 
Biome: skyris_vale
Type: Skyris
Info: Black hair, turquoise eyes and purple dress.
Spawn Rates: (Main variant ≈ 99.95%, Albino ≈ 0.03-0.05%)

• Stone [FTB StoneBlock 4 Mod] 
Type: Stone
Info: Dusty colors and darker brown hair. Different spawn percentage of eye colors, ripped black clothes and dust on clothes/skin. (Basically Nether Dark Version)
Spawn Rates: (Blue ≈ 3%, Brown ≈ 80%, Green ≈ 15%, Albino ≈ 0.03-0.05%)



- NOTE: For all default villager types biomes check https://Minecraft.fandom.com/wiki/Villager under the "Appearance" section, expand the "Variants" Table.
- NOTE: OptiFine doesn't save memory permanently so it assigns the non-default villager type (Mushroom, blossom, elf, etc) everytime you load the game (This doesn't include the default types such as taiga, snow, desert, jungle, etc). Meaning if for example your blossom villager is on the plains biome when you load the game then it will be a regular plains villager.



# ‿︵‿︵‿୨ Flower Farmers Info ୧‿︵‿︵‿

• There is a small chance a farmer villager turns into a flower girl (maybe 5% chance) (every villager type except nether, mushroom and alien).
• Every villager type has a different set of flowers that they can be.
• Check this file for more information on flower villagers: `Melodys Cute Villagers\assets\Minecraft\OptiFine\random\entity\villager\profession\farmer.properties`


# ‿︵‿︵‿୨ Current Supported Modded Professions ୧‿︵‿︵‿

- Updated: 08/03/2026

• 01. Lumberjack (https://www.curseforge.com/Minecraft/mc-mods/lumberjack-villagers)
• 02. Hunter (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 03. Enderologist (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 04. Netherologist (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 05. Oceanographer [More Villagers](https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 06. Alchemist (https://www.curseforge.com/Minecraft/mc-mods/villagersplus-forge)
• 07. Beekeeper (https://www.curseforge.com/Minecraft/mc-mods/productivebees)
• 08. Chef (https://www.curseforge.com/Minecraft/mc-mods/chefs-delight-forge)
• 09. Cook (https://www.curseforge.com/Minecraft/mc-mods/chefs-delight-forge)
• 10. Scribe (https://www.curseforge.com/Minecraft/mc-mods/ice-and-fire-dragons)
• 11. Electrician (https://www.curseforge.com/Minecraft/mc-mods/immersive-engineering)
• 12. Structural Engineer (https://www.curseforge.com/Minecraft/mc-mods/immersive-engineering)
• 13. Outfitter (https://www.curseforge.com/Minecraft/mc-mods/immersive-engineering)
• 14. Gunsmith (https://www.curseforge.com/Minecraft/mc-mods/immersive-engineering)
• 15. Machinist (https://www.curseforge.com/Minecraft/mc-mods/immersive-engineering)
• 16. Woodcutter (https://www.curseforge.com/Minecraft/mc-mods/sawmill)
• 17. Engineer (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 18. Florist (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 19. Miner (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 20. Forester (https://www.curseforge.com/Minecraft/mc-mods/more-villagers)
• 21. Occultist (https://www.curseforge.com/Minecraft/mc-mods/villagersplus-forge) 
• 22. Oceanographer [Villagers Plus] (https://www.curseforge.com/Minecraft/mc-mods/villagersplus-forge) 
• 23. Horticulturist (https://www.curseforge.com/Minecraft/mc-mods/villagersplus-forge )
• 24. Jeweler (https://www.curseforge.com/Minecraft/mc-mods/irons-jewelry)
• 25. Mechanic (https://www.curseforge.com/Minecraft/mc-mods/pneumaticcraft-repressurized)
• 26. Shady Wizard (https://www.curseforge.com/Minecraft/mc-mods/ars-nouveau)
• 27. Cartman (https://www.curseforge.com/Minecraft/mc-mods/railcraft)
• 28. Trackman (https://www.curseforge.com/Minecraft/mc-mods/railcraft)
• 29. Industrialist (https://www.curseforge.com/Minecraft/mc-mods/modern-industrialization)
• 30. Fluix Researcher (https://www.curseforge.com/Minecraft/mc-mods/applied-energistics-2)
• 31. Forager (https://www.curseforge.com/Minecraft/mc-mods/oh-the-biomes-weve-gone)
• 32. Werewolf (https://www.curseforge.com/Minecraft/mc-mods/evilcraft)
• 33. Engineer (https://www.curseforge.com/Minecraft/mc-mods/actually-additions)
• 34. Computer Scientist (https://www.curseforge.com/Minecraft/mc-mods/advanced-peripherals)
• 35. Merchant (https://www.curseforge.com/minecraft/mc-mods/farming-for-blockheads)
• 36. Stone Villager, Archaeologist, Dimensionalist, Geologist and the Echoes Projection (FTB Stoneblock 4) (https://www.curseforge.com/minecraft/modpacks/ftb-stoneblock-4)
• 37. Winemaker & Wandering Winemaker (https://www.curseforge.com/minecraft/mc-mods/lets-do-vinery)
• 38. Cook (https://www.curseforge.com/minecraft/mc-mods/lets-do-candlelight)
• 39. Sandy Merchant (https://www.curseforge.com/minecraft/mc-mods/lets-do-beachparty)
• 40. Trainer Association (https://modrinth.com/mod/rctmod)
• 41. Nurse & Nurse Joy (https://www.curseforge.com/minecraft/mc-mods/cobblemon)
• 42. All Villager Types For Natures Spirit (https://www.curseforge.com/minecraft/mc-mods/natures-spirit)
• 43. All Homesteads Professions (https://www.curseforge.com/minecraft/mc-mods/homesteads)
• 44. Animal Tamer Villager [Domestication Innovation](http://curseforge.com/minecraft/mc-mods/domestication-innovation)


# ‿︵‿︵‿୨ Pack Version Info ୧‿︵‿︵‿
• To remove the warning on the resource pack when you try to enable it, refer to the table below and change the "pack_format" value in the "pack.mcmeta" file to value associated to the version you're using:
• Refer to this page for the newer versions: https://Minecraft.fandom.com/wiki/Pack_format

[ Value |    Version  ]
[   9   | 1.19–1.19.2 ]
[   12  |   1.19.3    ]
[   13  |   1.19.4    ]
[   15  | 1.20–1.20.1 ]
[   18  |   1.20.2    ]
[   22  |1.20.3-1.20.4]
[   32  |   1.20.5    ]
[   34  |   1.21.- ?    ]


# ‿︵‿︵‿︵‿︵‿︵‿୨ Clarification ୧‿︵‿︵‿︵‿︵‿︵‿

### - I have heavily worked on, optimized, separated, and redid, all the textures/files/models/scripts since 2022, sketching ideas and physically working on this project to bring more variety of villagers and enhance them.
### - Voice files added by me for all mobs.
### - The original base model creator for the pack is said to have abandoned this pack and the Java porters struck out the "do not distribute" text as shown below and stated editing is allowed with credit given which I have done.

 ![Java port pack license](https://i.imgur.com/wFpF9Zk.png)


# ‿︵‿︵‿︵‿︵‿︵‿୨ Credits ୧‿︵‿︵‿︵‿︵‿︵‿

--- Special thanks to **heeneeh** on GitHub for testing, repetitive work, and math help.

--- Thank you to **Noodle** and to everyone who watched me stream this process and offered feedback! ---

--- Credit to **_jx** & Cute Mob Models Resource pack for the original models ---


︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵
