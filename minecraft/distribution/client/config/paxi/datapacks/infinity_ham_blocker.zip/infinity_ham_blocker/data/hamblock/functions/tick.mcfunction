# Remove if in main hand
execute as @a if entity @s[nbt={SelectedItem:{id:"relics:infinity_ham"}}] run clear @s relics:infinity_ham

# Remove if in off hand
execute as @a if entity @s[nbt={Inventory:[{Slot:-106b,id:"relics:infinity_ham"}]}] run clear @s relics:infinity_ham

# Remove from inventory silently
clear @a relics:infinity_ham
